
import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, 
  ShieldCheck, 
  Crown, 
  Zap, 
  ShoppingCart, 
  ChevronRight, 
  Users2,
  Trophy,
  Landmark, 
  BadgeCheck,
  Stethoscope,
  MapPin,
  MessageSquare,
  ExternalLink,
  Target,
  Rocket,
  ChevronDown,
  Sparkles,
  Flame,
  ShieldAlert
} from 'lucide-react';

const LOGO_URL = "https://media.discordapp.net/attachments/1463945618312396975/1467989844322947196/d41706667fd8f86b0ed534fc484c5927_2.webp?ex=69826394&is=69811214&hm=7a43ba633fc63e5eccf670b9fcd0a2046ac2a58042defcf6312d493a90f5a8b7&=&format=webp&width=274&height=274";
const DISCORD_LINK = "https://discord.gg/t8KCtCtmVc";

const CustomCursor = () => {
  const cursorRef = useRef<HTMLDivElement>(null);
  const followerRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      if (cursorRef.current && followerRef.current) {
        const { clientX: x, clientY: y } = e;
        cursorRef.current.style.left = `${x}px`;
        cursorRef.current.style.top = `${y}px`;
        
        // Follower movement with slight delay (handled by browser or manual interpolation)
        // Using direct assignment for performance, CSS transition handles the "lag"
        followerRef.current.style.left = `${x}px`;
        followerRef.current.style.top = `${y}px`;
      }
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'A' || 
        target.tagName === 'BUTTON' || 
        target.closest('button') || 
        target.closest('a') ||
        target.classList.contains('glass') ||
        target.classList.contains('clickable')
      ) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    window.addEventListener('mousemove', moveCursor);
    window.addEventListener('mouseover', handleMouseOver);

    return () => {
      window.removeEventListener('mousemove', moveCursor);
      window.removeEventListener('mouseover', handleMouseOver);
    };
  }, []);

  return (
    <div className={isHovering ? 'cursor-active' : ''}>
      <div id="custom-cursor" ref={cursorRef}></div>
      <div id="custom-cursor-follower" ref={followerRef}>
        <img src={LOGO_URL} alt="mini-logo" />
      </div>
    </div>
  );
};

/**
 * Funzione per gestire lo scroll senza cambiare l'URL, 
 * evitando il redirect a aistudio.google.com causato dagli anchor standard.
 */
const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>, id: string) => {
  e.preventDefault();
  const element = document.getElementById(id);
  if (element) {
    const offset = 80; // Compensazione per la navbar fissa
    const bodyRect = document.body.getBoundingClientRect().top;
    const elementRect = element.getBoundingClientRect().top;
    const elementPosition = elementRect - bodyRect;
    const offsetPosition = elementPosition - offset;

    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth'
    });
  }
};

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'glass py-3 shadow-2xl border-b border-white/5' : 'py-6 bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={(e: any) => scrollToSection(e, 'home')}
        >
          <img src={LOGO_URL} alt="Logo" className="w-12 h-12 rounded-full border-2 border-green-500 shadow-lg shadow-green-500/20 object-cover group-hover:scale-110 transition-transform" />
          <div className="flex flex-col">
            <span className="font-outfit font-black text-xl md:text-2xl tracking-tight hidden sm:block uppercase leading-none">ITALIA</span>
            <span className="font-outfit font-black text-xl md:text-2xl tracking-tight hidden sm:block uppercase leading-none text-green-500">REVOLUTION</span>
          </div>
        </div>
        <div className="flex gap-4 md:gap-10 items-center text-xs md:text-sm font-bold text-gray-400 uppercase tracking-widest">
          <button onClick={(e) => scrollToSection(e, 'home')} className="hover:text-white transition-colors relative after:content-[''] after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-0.5 after:bg-green-500 hover:after:w-full after:transition-all">Home</button>
          <button onClick={(e) => scrollToSection(e, 'fazioni')} className="hover:text-white transition-colors relative after:content-[''] after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-0.5 after:bg-green-500 hover:after:w-full after:transition-all">Fazioni</button>
          <button onClick={(e) => scrollToSection(e, 'shop')} className="hover:text-white transition-colors relative after:content-[''] after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-0.5 after:bg-green-500 hover:after:w-full after:transition-all">Shop</button>
          <button onClick={(e) => scrollToSection(e, 'staff')} className="hover:text-white transition-colors relative after:content-[''] after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-0.5 after:bg-green-500 hover:after:w-full after:transition-all">Staff</button>
          <a href={DISCORD_LINK} target="_blank" rel="noopener noreferrer" className="btn-gradient text-white px-5 py-2.5 rounded-xl font-bold hover:scale-105 transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(34,197,94,0.3)]">
            DISCORD <MessageSquare size={16} />
          </a>
        </div>
      </div>
    </nav>
  );
};

const Hero = () => (
  <section id="home" className="relative pt-48 pb-32 overflow-hidden hero-gradient">
    <div className="max-w-7xl mx-auto px-6 relative z-10 flex flex-col items-center">
      <div className="flex flex-col items-center text-center max-w-5xl">
        <div className="inline-flex items-center gap-2 bg-green-500/10 text-green-400 px-5 py-2 rounded-full text-[10px] font-black tracking-[0.2em] uppercase mb-8 border border-green-500/20">
          <Target size={14} /> La Nuova Era del Roleplay
        </div>
        <h1 className="font-outfit text-7xl md:text-9xl font-black mb-8 leading-none tracking-tighter">
          LA <span className="text-green-500">RIVOLUZIONE</span> <br /> 
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-300 to-gray-600">
            DEL REALISMO
          </span>
        </h1>
        <p className="max-w-3xl text-gray-400 text-lg md:text-2xl mb-12 font-medium leading-relaxed">
          Un'esperienza immersiva su Roblox dedicata alla qualità del RP.
          Fazioni istituzionali, sistemi avanzati e una community d'elite.
        </p>
        <div className="flex flex-wrap gap-6 justify-center mb-24">
          <a href={DISCORD_LINK} target="_blank" rel="noopener noreferrer" className="px-10 py-5 btn-gradient rounded-2xl font-black text-white text-lg flex items-center gap-3 hover:scale-105 transition-all shadow-2xl">
            ENTRA ORA <MessageSquare size={24} />
          </a>
          <button onClick={(e: any) => scrollToSection(e, 'fazioni')} className="px-10 py-5 glass rounded-2xl font-black text-lg flex items-center gap-3 hover:bg-white/10 transition-all border border-white/10">
            SCOPRI LE FAZIONI <ChevronRight size={24} />
          </button>
        </div>
      </div>

      <div className="w-full max-w-6xl">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 px-4">
          {[
            { icon: <Users2 className="text-green-500" />, label: "Giocatori Online", val: "20+" },
            { icon: <MessageSquare className="text-blue-500" />, label: "Membri Discord", val: "250+" },
            { icon: <Zap className="text-yellow-500" />, label: "Status Server", val: "ATTIVO" },
            { icon: <Trophy className="text-red-500" />, label: "Qualità RP", val: "ECCELSO" }
          ].map((stat, i) => (
            <div key={i} className="glass p-6 md:p-8 rounded-[2rem] flex items-center gap-5 group hover:border-green-500/40 transition-all duration-500 hover:bg-white/[0.05] shadow-lg">
              <div className="flex-shrink-0 p-4 bg-white/5 rounded-2xl group-hover:bg-green-500/10 transition-all group-hover:rotate-12">
                {stat.icon}
              </div>
              <div className="overflow-hidden">
                <div className="text-2xl font-black font-outfit tracking-tighter truncate">{stat.val}</div>
                <div className="text-gray-500 text-[9px] uppercase tracking-[0.2em] font-bold truncate">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

const Fazioni = () => {
  const fazioniData = [
    { name: "Arma dei Carabinieri", icon: <ShieldCheck className="text-blue-600" />, desc: "Nei secoli fedele. Difendi l'ordine pubblico.", color: "border-blue-500/20" },
    { name: "Guardia di Finanza", icon: <Landmark className="text-yellow-500" />, desc: "Contrasto agli illeciti economici e doganali.", color: "border-yellow-500/20" },
    { name: "Polizia di Stato", icon: <BadgeCheck className="text-blue-400" />, desc: "Sub Lege Libertas. Al servizio dei cittadini.", color: "border-blue-400/20" },
    { name: "Autorità Giudiziaria", icon: <Crown className="text-purple-500" />, desc: "Il massimo organo della giustizia nel server.", color: "border-purple-500/20" },
    { name: "Prefettura", icon: <Landmark className="text-red-600" />, desc: "Gestione burocratica e amministrativa.", color: "border-red-600/20" },
    { name: "Croce Rossa Italiana", icon: <Stethoscope className="text-red-500" />, desc: "Soccorso medico e assistenza umanitaria.", color: "border-red-500/20" },
    { name: "Polizia Locale", icon: <MapPin className="text-slate-500" />, desc: "Sicurezza urbana e controllo del traffico.", color: "border-gray-500/20" }
  ];

  return (
    <section id="fazioni" className="py-32 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
          <div>
            <h2 className="text-5xl md:text-7xl font-outfit font-black mb-6 italic uppercase tracking-tighter">I NOSTRI <br/><span className="text-green-500">CORPI STATALI</span></h2>
            <div className="w-32 h-2 bg-green-500 rounded-full"></div>
          </div>
          <p className="text-gray-400 max-w-md font-medium text-lg leading-relaxed">
            Ogni corpo istituzionale è gestito con protocolli reali. Addestramenti costanti e carriere basate sul merito.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {fazioniData.map((f, i) => (
            <div key={i} className={`glass p-10 rounded-[3rem] border ${f.color} hover:bg-white/5 transition-all duration-500 group cursor-default relative overflow-hidden`}>
              <div className="absolute top-[-20px] right-[-20px] w-24 h-24 bg-white/5 rounded-full blur-2xl group-hover:bg-green-500/10 transition-all"></div>
              <div className="mb-8 group-hover:scale-110 group-hover:rotate-6 transition-transform inline-block">
                {React.cloneElement(f.icon as React.ReactElement, { size: 50 })}
              </div>
              <h3 className="text-2xl font-black mb-4 font-outfit">{f.name}</h3>
              <p className="text-gray-500 text-sm leading-relaxed font-medium">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Shop = () => {
  const boostRewards = [
    { level: "1 Boost", reward: "100.000€ Economy", icon: <Zap className="text-white" /> },
    { level: "2 Boost", reward: "Fazione Gratis + 150k", icon: <Zap className="text-green-400" /> },
    { level: "3 Boost", reward: "Immatricolazione + 200k", icon: <Zap className="text-yellow-400" /> },
    { level: "4 Boost", reward: "Bando Staff + 250k + Full", icon: <Zap className="text-red-500" /> }
  ];

  return (
    <section id="shop" className="py-32 bg-white/[0.01]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-24">
          <h2 className="text-6xl md:text-7xl font-outfit font-black mb-6 uppercase tracking-tighter">SOSTIENI LA <span className="text-green-500">RIVOLUZIONE</span></h2>
          <p className="text-gray-500 max-w-2xl mx-auto font-medium text-lg italic">Il tuo supporto ci permette di implementare script esclusivi e migliorare la qualità delle sessioni.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-7">
            <h3 className="text-3xl font-black mb-10 font-outfit flex items-center gap-3"><Rocket className="text-green-500" /> VANTAGGI BOOSTERS</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {boostRewards.map((b, i) => (
                <div key={i} className="glass p-8 rounded-3xl hover:translate-y-[-5px] transition-all border border-white/5 group">
                  <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:bg-green-500/10 transition-colors">
                    {b.icon}
                  </div>
                  <div className="font-black text-xl mb-2 text-white">{b.level}</div>
                  <div className="text-green-400 text-sm font-bold uppercase tracking-wider">{b.reward}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="glass p-10 rounded-[3rem] border-2 border-green-500/40 bg-green-500/10 relative overflow-hidden group shadow-[0_0_50px_rgba(34,197,94,0.1)]">
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-green-500/20 blur-[80px]"></div>
              <div className="flex items-center gap-4 mb-8">
                <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center shadow-xl">
                  <Users size={32} className="text-green-400" />
                </div>
                <h3 className="text-4xl font-black font-outfit leading-tight uppercase">
                  SECONDO <br/><span className="text-green-500">PERSONAGGIO</span>
                </h3>
              </div>
              
              <p className="text-gray-300 mb-10 text-lg leading-relaxed font-medium">
                Vuoi essere sia un <span className="text-white font-bold">Comandante</span> che un <span className="text-green-400 font-bold">Civile Spericolato</span>? 
                Gestisci due vite separate all'interno della community.
              </p>
              
              <div className="bg-black/60 p-8 rounded-3xl mb-10 border border-white/10 backdrop-blur-md">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-400 font-black uppercase text-[10px] tracking-widest">OFFERTA LIMITATA</span>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-500 line-through text-sm">100</span>
                    <span className="text-green-400 font-black text-3xl">50</span>
                    <span className="text-green-400 text-xs font-bold">ROBUX</span>
                  </div>
                </div>
                <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <div className="w-full h-full bg-gradient-to-r from-green-600 to-green-400 shadow-[0_0_15px_#22c55e]"></div>
                </div>
              </div>

              <a 
                href="https://www.roblox.com/it/game-pass/1579989576/Secondo-PG-50-robux" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full btn-gradient text-white py-6 rounded-2xl font-black text-xl flex items-center justify-center gap-4 hover:scale-[1.03] active:scale-95 transition-all shadow-2xl relative z-10"
              >
                ACQUISTA ORA <ShoppingCart size={24} />
              </a>
              <p className="text-center mt-6 text-[10px] text-gray-500 font-black uppercase tracking-[0.4em]">Official Roblox Gamepass</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const StaffMemberCard = ({ name, role, color, icon, animationClass }: { name: string, role: string, color: string, icon: React.ReactNode, animationClass: string, key?: React.Key }) => (
  <div className={`glass p-10 rounded-[3rem] border-t-8 ${color} hover:translate-y-[-10px] transition-all duration-500 group relative overflow-hidden flex flex-col items-center text-center shadow-xl hover:shadow-green-500/10`}>
    <div className="absolute inset-0 bg-gradient-to-b from-white/[0.02] to-transparent pointer-events-none"></div>
    
    <div className={`w-28 h-28 rounded-full bg-black/40 border-2 border-white/10 flex items-center justify-center mb-8 relative z-10 group-hover:border-green-500/50 transition-colors shadow-2xl ${animationClass}`}>
      <div className="absolute inset-[-4px] rounded-full border border-green-500/0 group-hover:border-green-500/20 group-hover:scale-110 transition-all duration-700"></div>
      {icon}
    </div>

    <div className="relative z-10">
      <div className="text-3xl font-black font-outfit text-white mb-2 group-hover:text-glow transition-all uppercase tracking-tight">{name}</div>
      <div className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black tracking-[0.3em] text-gray-400 uppercase group-hover:bg-green-500/10 group-hover:text-green-400 transition-all">
        {role}
      </div>
    </div>
    
    <div className="absolute bottom-[-20px] left-1/2 -translate-x-1/2 w-40 h-40 bg-green-500/5 blur-3xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
  </div>
);

const Staff = () => {
  const staff = [
    { 
      name: "Sama", role: "FOUNDER", color: "border-yellow-500", 
      icon: <div className="text-6xl drop-shadow-[0_0_15px_rgba(234,179,8,0.6)] animate-pulse">👑</div>,
      animationClass: "animate-[bounce_3s_infinite]"
    },
    { 
      name: "Itsrome", role: "CO-FOUNDER", color: "border-yellow-400", 
      icon: <Sparkles className="w-14 h-14 text-yellow-300 animate-[spin_4s_linear_infinite]" />,
      animationClass: ""
    },
    { 
      name: "17.FARINA", role: "OWNER", color: "border-red-500", 
      icon: <ShieldAlert className="w-14 h-14 text-red-500 animate-pulse" />,
      animationClass: "animate-[pulse_2s_infinite]"
    },
    { 
      name: "Manuel", role: "CO-OWNER", color: "border-red-400", 
      icon: <div className="text-5xl animate-[spin_10s_linear_infinite]">🎩</div>,
      animationClass: ""
    },
    { 
      name: "samuele04959", role: "COMM. MANAGER", color: "border-green-500", 
      icon: <Flame className="w-14 h-14 text-green-500 animate-[bounce_2s_infinite]" />,
      animationClass: ""
    },
    { 
      name: "d4monds", role: "COMM. MANAGER", color: "border-blue-500", 
      icon: <div className="text-6xl animate-[pulse_1.5s_infinite]">💎</div>,
      animationClass: ""
    },
    { 
      name: "just_44slay", role: "STAFF MANAGER", color: "border-purple-500", 
      icon: <Zap className="w-14 h-14 text-purple-400 animate-pulse" />,
      animationClass: "animate-[wiggle_1s_infinite]"
    },
    { 
      name: "Pizzanapoli", role: "STAFF MANAGER", color: "border-orange-500", 
      icon: <div className="text-6xl group-hover:rotate-[360deg] transition-transform duration-1000">🍕</div>,
      animationClass: ""
    },
  ];

  return (
    <section id="staff" className="py-32 relative overflow-hidden bg-black/40">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-24">
          <div className="inline-block p-4 glass rounded-3xl mb-6 shadow-2xl relative overflow-hidden group">
            <div className="absolute inset-0 bg-yellow-500/10 blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <Crown size={60} className="text-yellow-500 relative z-10 animate-[bounce_4s_infinite]" />
          </div>
          <h2 className="text-5xl md:text-8xl font-outfit font-black mb-6 uppercase tracking-tighter italic">LA NOSTRA <br/><span className="text-green-500">AMMINISTRAZIONE</span></h2>
          <div className="w-40 h-2 bg-green-500 mx-auto rounded-full mb-8"></div>
          <p className="text-gray-400 max-w-xl mx-auto font-medium text-xl leading-relaxed">
            Il comando supremo di Italia Revolution RP. Professionalità e visione per un futuro leggendario.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {staff.map((s, i) => (
            <StaffMemberCard 
              key={i} 
              name={s.name}
              role={s.role}
              color={s.color}
              icon={s.icon}
              animationClass={s.animationClass}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="py-24 glass border-t-0 mt-32 relative z-10 overflow-hidden">
    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-green-500 via-white to-red-500 opacity-30"></div>
    <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-20 items-center">
      <div className="text-center md:text-left">
        <div className="flex items-center justify-center md:justify-start gap-4 mb-6 group cursor-pointer" onClick={(e: any) => scrollToSection(e, 'home')}>
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 rounded-full border border-green-500 p-1 group-hover:rotate-12 transition-transform shadow-lg shadow-green-500/20" />
          <div className="flex flex-col">
            <span className="font-outfit font-black text-2xl tracking-tight uppercase leading-none">ITALIA</span>
            <span className="font-outfit font-black text-2xl tracking-tight uppercase leading-none text-green-500">REVOLUTION</span>
          </div>
        </div>
        <p className="text-gray-500 text-sm max-w-xs mx-auto md:mx-0 font-medium leading-relaxed">
          La rivoluzione del roleplay istituzionale su Roblox Italia. Unisciti all'elite.
        </p>
      </div>
      
      <div className="flex flex-col items-center gap-6">
        <div className="text-white font-black text-xs tracking-[0.4em] uppercase mb-2">NAVIGAZIONE</div>
        <div className="flex flex-wrap justify-center gap-8 text-gray-400 font-bold uppercase text-[10px] tracking-[0.2em]">
          <button onClick={(e) => scrollToSection(e, 'home')} className="hover:text-green-500 transition-colors uppercase font-bold">Home</button>
          <button onClick={(e) => scrollToSection(e, 'fazioni')} className="hover:text-green-500 transition-colors uppercase font-bold">Fazioni</button>
          <button onClick={(e) => scrollToSection(e, 'shop')} className="hover:text-green-500 transition-colors uppercase font-bold">Shop</button>
          <a href={DISCORD_LINK} target="_blank" className="hover:text-green-500 transition-colors uppercase font-bold">Discord</a>
        </div>
      </div>

      <div className="text-center md:text-right">
        <div className="text-gray-400 text-[10px] font-black uppercase tracking-[0.5em] mb-4">Developed for Revolutionaries</div>
        <div className="text-gray-600 text-[11px] font-bold italic leading-loose">
          © 2025 ITALIA REVOLUTION RP. <br/> 
          POWERED BY COMMUNITY PASSION.
        </div>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] selection:bg-green-500 selection:text-black">
      <CustomCursor />
      <Navbar />
      <Hero />
      <div className="bg-gradient-to-b from-[#0a0a0a] via-[#050505] to-black">
        <Fazioni />
        <Shop />
        <Staff />
      </div>
      <Footer />
      
      <div className="fixed top-[-10%] right-[-10%] w-[60vw] h-[60vw] bg-green-600/5 rounded-full blur-[180px] -z-10 pointer-events-none animate-pulse"></div>
      <div className="fixed bottom-[-10%] left-[-10%] w-[60vw] h-[60vw] bg-green-800/5 rounded-full blur-[180px] -z-10 pointer-events-none animate-pulse"></div>
      <div className="fixed top-[30%] left-[10%] w-[30vw] h-[30vw] bg-white/[0.01] rounded-full blur-[120px] -z-10 pointer-events-none"></div>
    </div>
  );
}
